package org.example.models;

public class MonsterCard extends Card {
    public MonsterCard(String name, double damage, String elementType) {
        super(name, damage, elementType);
    }
}
