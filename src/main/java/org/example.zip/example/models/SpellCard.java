package org.example.models;

public class SpellCard extends Card {
    public SpellCard(String name, double damage, String elementType) {
        super(name, damage, elementType);
    }
}
